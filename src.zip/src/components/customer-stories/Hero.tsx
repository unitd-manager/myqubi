export default function Hero() { const metrics = [["85%", "Average reduction in processing time across all clients"],
     ["10x", "Average increase in operational throughput"], ["$50M+", "Documented savings delivered to clients"],
     ["99%+", "Client retention rate"]]; return <header className="cs-hero" id="top"><div className="cs-shell">
        <div className="cs-hero-copy"><span className="cs-eyebrow">Proven Results</span><h1>Real Work.<br />
        <em>Real Outcomes.</em></h1><p>Proven outcomes across enterprise workflows. No demos. No POCs.<br />
        Real execution delivering measurable business impact.</p>
        </div><div className="cs-hero-metrics">{metrics.map(([value, label]) => 
            <div className="cs-hero-metric" key={label}><strong>{value}</strong><span>{label}</span></div>)}</div></div></header>; }