import qubiLogo from "@/assets/qubi-logo1.png";
import qboticaLogo from "@/assets/logo-front.webp";

const QubiFooter = () => {
  return (
    <footer>
      <div className="site-shell">
        <div className="footer-grid">
          <div className="footer-intro">
            <a className="brand" href="/#top">
              <div className="brand-logo-wrap">
                <img src={qubiLogo} alt="qubi" className="brand-mark" />
                <div className="brand-divider"></div>
                <div className="powered-by" aria-label="Powered by qBotica">
                  <span>POWERED BY</span>
                  <img src={qboticaLogo} alt="qBotica" className="qbotica-wordmark" />
                </div>
              </div>
            </a>
            <p>The agentic orchestration platform connecting AI agents, automations, systems, and people.</p>
          </div>
          <div className="footer-col">
            <strong>Product</strong>
            <a href="/#why">Why qubi</a>
            <a href="/#how">How it works</a>
            <a href="/#enterprise">Built for enterprise</a>
            <a href="/pricing">Pricing</a>
          </div>
          <div className="footer-col">
            <strong>Solutions</strong>
            <a href="/#use-cases">Operations</a>
            <a href="/#use-cases">Finance</a>
            <a href="/#use-cases">Human resources</a>
            <a href="/#use-cases">IT service management</a>
          </div>
          <div className="footer-col">
            <strong>Company</strong>
            <a href="https://www.qbotica.com/" target="_blank" rel="noreferrer">qBotica ↗</a>
            <a href="/customers">Customers</a>
            <a href="https://meetings.hubspot.com/enterprisedemo/qubi-consultation" target="_blank" rel="noreferrer">Book a demo</a>
          </div>
        </div>
        <div className="copyright">
          <span>
            Privacy Policy · Terms of Service
          </span>
        </div>
      </div>
    </footer>
  );
};

export default QubiFooter;